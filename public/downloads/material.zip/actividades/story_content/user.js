function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6eDnilN8lhe":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

